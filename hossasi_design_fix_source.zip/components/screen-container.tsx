import { View, type ViewProps } from "react-native";
import { SafeAreaView, type Edge } from "react-native-safe-area-context";

import { cn } from "@/lib/utils";

export interface ScreenContainerProps extends ViewProps {
  /**
   * SafeArea edges to apply. Defaults to ["top", "left", "right"].
   * Bottom is typically handled by Tab Bar.
   */
  edges?: Edge[];
  /**
   * Tailwind className for the content area.
   */
  className?: string;
  /**
   * Additional className for the outer container (background layer).
   */
  containerClassName?: string;
  /**
   * Additional className for the SafeAreaView (content layer).
   */
  safeAreaClassName?: string;
}

/**
 * A container component that properly handles SafeArea and background colors.
 *
 * The outer View extends to full screen (including status bar area) with the background color,
 * while the inner SafeAreaView ensures content is within safe bounds.
 *
 * Usage:
 * ```tsx
 * <ScreenContainer className="p-4">
 *   <Text className="text-2xl font-bold text-foreground">
 *     Welcome
 *   </Text>
 * </ScreenContainer>
 * ```
 */
export function ScreenContainer({
  children,
  edges = ["top", "left", "right"],
  className,
  containerClassName,
  safeAreaClassName,
  style,
  ...props
}: ScreenContainerProps) {
  return (
    <View
      className={cn(
        "flex-1 w-full",
        "bg-[#0d0f1a]",
        containerClassName
      )}
      style={[{ flex: 1, width: '100%', backgroundColor: '#0d0f1a' }, style]}
      {...props}
    >
      <SafeAreaView
        edges={edges}
        className={cn("flex-1 w-full", safeAreaClassName)}
        style={{ flex: 1, width: '100%', backgroundColor: '#0d0f1a' }}
      >
        <View className={cn("flex-1 w-full", className)} style={{ flex: 1, width: '100%' }}>{children}</View>
      </SafeAreaView>
    </View>
  );
}
