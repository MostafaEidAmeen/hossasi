/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx,ts,tsx}',
    './components/**/*.{js,jsx,ts,tsx}',
    './hooks/**/*.{js,jsx,ts,tsx}',
    './lib/**/*.{js,jsx,ts,tsx}',
  ],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f1f0ff',
          100: '#e8e6ff',
          200: '#d4d0ff',
          300: '#b9b2ff',
          400: '#9b91ff',
          500: '#7c6efa',
          600: '#6657e8',
          700: '#5445c8',
          800: '#4338a4',
          900: '#342d7e',
        },
      },
    },
  },
  plugins: [],
};
